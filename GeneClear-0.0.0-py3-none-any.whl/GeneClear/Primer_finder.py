from Bio.Seq import Seq
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from tqdm import trange
from Bio.SeqUtils import MeltingTemp
import multiprocessing
from itertools import product
import numpy as np
import pandas as pd
import re
import multiprocessing # Step I : 导入模块
from multiprocessing import cpu_count#读取CPU核心数用于匹配线程数
import GeneClear.bez as bez

class Primer_finder():
	def __init__(self, options):
		self.minnt = 18
		self.maxnt = 30
		self.targetmin = 80
		self.targetmax = 300
		self.sequencing_limit = 5000000 # ont测序长度
		self.gc_range = '40:60'
		self.tm_range = '55:65'
		self.cpu = cpu_count() - 1
		for k, v in options:
			setattr(self, str(k), v)
			print(k, ' = ', v)

		self.minnt = int(self.minnt)
		self.maxnt = int(self.maxnt)
		self.targetmin = int(self.targetmin)
		self.targetmax = int(self.targetmax)
		self.sequencing_limit = int(self.sequencing_limit)
		self.cpu = int(self.cpu)


	def readGC(self,s):
		return 100*(s.count('C')+s.count('G'))/len(s)

	def calculate_primer_properties(self,primer_sequence):
		# 计算引物的性质，例如 Tm
		tm = MeltingTemp.Tm_Wallace(primer_sequence)
		return tm

	def measure(self,primer1,primer2):
		GC1,GC2 = self.readGC(primer1),self.readGC(primer2)
		TM1,TM2 = self.calculate_primer_properties(primer1),self.calculate_primer_properties(primer2)
		return GC1,GC2,TM1,TM2

	def find_occurrences_regex(self,text, pattern):
		occurrences = []
		for i in range(len(text)-len(pattern)):
			seq0 = text[i:i+len(pattern)]
			if seq0 == pattern:
				occurrences.append(i)
		# occurrences = [match.start() for match in re.finditer(pattern, text)]
		return occurrences

	def find_occurrences_regexs(self,text, patterns,primerl):
		occurrences = {}
		for i in trange(len(text)-primerl):
			seq0 = text[i:i+primerl]
			if seq0 in patterns:
				if seq0 not in occurrences.keys():
					occurrences[seq0] = [i]
				else:
					occurrences[seq0].append(i)
				# occurrences.append(i)
		# occurrences = [match.start() for match in re.finditer(pattern, text)]
		return occurrences


	def find(self,pairlt,genome,primerl):
		print(len(pairlt),'Candidate primer pairs ,length ',primerl)
		print('Verify the uniqueness of primers...')
		pairs = []
		indexs = {}

		allprimerlist = []
		for i in trange(len(pairlt)):
			pair = pairlt[i]
			primer1,primer2 = pair[4],pair[7]
			allprimerlist = allprimerlist + [pair[4],pair[7]]
		allprimerlist = list(set(allprimerlist))
		for chro in genome.keys():
			print('Scan chromosome',chro,'...')
			chromosome = str(genome[chro].seq).upper()
			indexs[chro] = self.find_occurrences_regexs(chromosome, allprimerlist,primerl)

		print('Primer distance filtering...')
		for i in trange(len(pairlt)):
			pair = pairlt[i]
			primer1,primer2 = pair[4],pair[7]
			pairs0 = []
			for chro in genome.keys():
				if primer1 not in indexs[chro].keys() or primer2 not in indexs[chro].keys():
					continue

				index1 = indexs[chro][primer1]
				index2 = indexs[chro][primer2]

				if len(index1) == 0 or len(index2) == 0:
					continue

				if len(index1) > 1:
					result = product(index1, repeat=2) # 同一个引物之间的距离不能低于测序长度+目标长度+最长引物长度
					lt = [abs(pair[0]-pair[1]) for pair in result]
					# print(lt)
					lt0 = [x for x in lt if x != 0]
					# print(lt0)
					if min(lt0) < self.sequencing_limit+self.targetmax+self.maxnt:
						continue

				if len(index2) >1:
					result = product(index2, repeat=2)
					lt = [abs(pair[0]-pair[1]) for pair in result]
					lt0 = [x for x in lt if x != 0]
					if min(lt0) < self.sequencing_limit+self.targetmax+self.maxnt:
						continue

				# result = product(index1, index2)
				# lt = [abs(pair[0]-pair[1]) for pair in result]
				# if min(lt) < self.sequencing_limit:
				# 	continue

				pairs0.append([chro,primer1,primer2])
			if len(pairs0) != 1:
				continue
			pairs.append(pair)
			# print(primer1,primer2,target)
		print('There are',len(pairs),'primers that meet the conditions.   -> ',primerl,' over!')
		return pairs


	def findp(self,sequence,genome,name):
		d = {'A':'T','T':'A','G':'C','C':'G','N':'N'}
		primer = []
		pairs = {}
		length = len(sequence)
		for i in trange(length-self.targetmin-(2*self.minnt)):
			for primerl in range(self.minnt,self.maxnt):
				if i + self.targetmin + (2*primerl) > length:
					break
				primer1 = sequence[i:i+primerl] # 同链
				if 'N' in primer1:
					continue
				primer1rc = ''.join([d[i] for i in primer1])
				for targetl in range(self.targetmin,self.targetmax):
					if i + targetl + (2*primerl) > length:
						break
					target = sequence[i+primerl:i+primerl+targetl]
					primer2 = sequence[i+primerl+targetl:i+targetl+(2*primerl)] # 同链
					if 'N' in primer2:
						continue
					primer2rc = ''.join([d[i] for i in primer2])

					GC1a,GC2a,TM1a,TM2a = self.measure(primer1,primer2rc)# 引物异链反向 末尾为A
					GC1b,GC2b,TM1b,TM2b = self.measure(primer1rc,primer2)# 引物异链反向 末尾为A
					# print(GC1a,GC2a,TM1a,TM2a)
					if min(GC1a,GC2a) < float(self.gc_range.split(':')[0]) or max(GC1a,GC2a) > float(self.gc_range.split(':')[1]):
						continue

					if min(TM1a,TM2a) < float(self.tm_range.split(':')[0]) or max(TM1a,TM2a) > float(self.tm_range.split(':')[1]) or abs(TM1a-TM2a) or primer1[-1] != 'T' or primer2rc[-1] != 'T':
						if min(TM1b,TM2b) < float(self.tm_range.split(':')[0]) or max(TM1b,TM2b) > float(self.tm_range.split(':')[1]) or abs(TM1b-TM2b) > 3 or primer1rc[-1] != 'T' or primer2[-1] != 'T':
							continue
						else:
							pair = [i,i+primerl,i+primerl+targetl,i+targetl+(2*primerl),primer1,primer2rc,primer1rc,primer2,i+primerl,i+primerl+targetl,target,'b']
					else:
						pair = [i,i+primerl,i+primerl+targetl,i+targetl+(2*primerl),primer1,primer2rc,primer1rc,primer2,i+primerl,i+primerl+targetl,target,'a']
					# if (min(TM1a,TM2a) < float(self.tm_range.split(':')[0]) or max(TM1a,TM2a) > float(self.tm_range.split(':')[1]) or abs(TM1a-TM2a) > 3 or primer1[-1] != 'T' or primer2rc[-1] != 'T') and (min(TM1b,TM2b) < float(self.tm_range.split(':')[0]) or max(TM1b,TM2b) > float(self.tm_range.split(':')[1]) or abs(TM1b-TM2b) > 3 or primer1rc[-1] != 'T' or primer2[-1] != 'T'):
					# 	continue
					# GC1b,GC2b,TM1b,TM2b = self.measure(primer1rc,primer2)# 引物异链反向 末尾为A
					# if min(GC1b,GC2b) < float(self.gc_range.split(':')[0]) or max(GC1b,GC2b) > float(self.gc_range.split(':')[1]) or min(TM1b,TM2b) < float(self.tm_range.split(':')[0]) or max(TM1b,TM2b) > float(self.tm_range.split(':')[1]) or abs(TM1b-TM2b) > 3 or primer1rc[-1] != 'T' or primer2[-1] != 'T':
					# 	continue

					
					if primerl not in pairs.keys():
						pairs[primerl] = [pair]
					else:
						pairs[primerl].append(pair)

		print(len(pairs),'Candidate...')
		print('Verify the uniqueness of primer length...')
		for primerl in pairs.keys():
			pairlt = pairs[primerl]
			pair = self.find(pairlt,genome,primerl)
			primer = primer + pair

		# pool = multiprocessing.Pool(processes = self.cpu) # Step II : 进程池
		# result = []
		# for primerl in pairs.keys():
		# 	pairlt = pairs[primerl]
		# 	result.append(pool.apply_async(self.find, args=(pairlt,genome,primerl)))
		# pool.close()
		# pool.join()
		# for item in result:
		# 	pair = item.get()
		# 	primer = primer + pair

		print(len(primer),' pairs of ',name,' gene primers were found.')
		return primer

	def run(self):
		genome = SeqIO.to_dict(SeqIO.parse(self.genome, "fasta"))# 提取之后直接返回字典
		out_primer = open(self.out_primer,'w')
		out_primer.write('### GeneClear\n')
		out_primer.write('### charles_kiko@163.com\n')
		out_primer.write('### Primer_finder\n')
		out_primer.write('### 注！type a : primer1,primer2rc 引物2为primer2的反向互补序列;type b ： primer1rc,primer2 引物1为primer1的反向互补序列\n')
		out_primer.write('\t'.join(['chr','gene','primer1start','primer1end','primer2start','primer2end','primer1','primer2rc','primer1rc','primer2','targetstart','targetend','target','type'])+'\n')
		targetgene = pd.read_csv(self.targetgene,header = None, sep='\t')[0].to_list()
		gff = pd.read_csv(self.gff,header = None, sep='\t')
		dic = gff.groupby(0).groups# 按照第几列分组
		gene = {}
		for key in dic.keys():
			# print(" ******** ",key," ******** ")
			local = gff.loc[dic[key]].sort_values(by=[0,3],ascending= [True,True])
			local.reset_index(drop=True,inplace=True)
			# print(local)
			for index,row in local.iterrows():
				if row[1] in targetgene:
					dic0 = {'chr':row[0],'start':row[2],'end':row[3],'strand':row[4]}
					gene[row[1]] = dic0
		for name in targetgene:
			# sequence
			chromosome = str(genome[gene[name]['chr']].seq).upper()
			print('>'+name)
			sequence = chromosome[gene[name]['start']:gene[name]['end']]
			print(sequence)
			primer = self.findp(sequence,genome,name)
			for pair in primer:
				out_primer.write('\t'.join([gene[name]['chr'],name] + [str(i) for i in pair])+'\n')
				print('\t'.join([gene[name]['chr'],name] + [str(i) for i in pair]))
		out_primer.close()

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from matplotlib.colors import Normalize, ListedColormap,LinearSegmentedColormap
import sys
import GeneClear.bez as bez

class Visualization_GO():
	def __init__(self, options):
	##### circle parameters
		self.dpi = '600'
		self.top = '20'
		self.class_dic = 'Biological process:#0095d9,Molecular function:#f39800,Cellular component:#d7003a'
		for k, v in options:
			setattr(self, str(k), v)
			print(k, ' = ', v)
		self.dpi = int(self.dpi)
		self.top = int(self.top)

	def value_to_color(self,value, cmap, vmin, vmax):
		norm = Normalize(vmin=vmin, vmax=vmax)
		return cmap(norm(value))
	def run(self):
		# 读取GO分析文件
		df = pd.read_csv(self.tb_file,header = 0, sep='\t', comment='#')
		# 计算Rich factor
		df['Rich_factor'] = df['HitsGenesCountsInSelectedSet'] / df['HitsGenesCountsInBackground']
		# 根据'Rich_factor'排序并选择前20个
		df = df.sort_values(by='Rich_factor', ascending=False).head(self.top).sort_values(by=['Class','GO_Name'],ascending= [True,True])
		df.reset_index(drop=True,inplace=True)
		# 将索引添加为一列
		df.reset_index(drop=False, inplace=True)
		# print(df)
		xvaluemax,xvaluemin = max(df['Rich_factor']),min(df['Rich_factor'])
		index_to_go_name = dict(zip(df.index, df['GO_Name']))

		classes = df['Class'].unique()

		# 绘制气泡图
		fig, ax = plt.subplots(figsize=(12, 8))

		# 设置颜色映射

		colors = sns.color_palette("rainbow", as_cmap=True)
		cmap = LinearSegmentedColormap.from_list("Custom", colors(np.linspace(0, 1, 256)))

		Class_dic = {}
		for i in self.class_dic.split(','):
			lt = i.split(':')
			Class_dic[lt[0]] = lt[1]

		for i, class_name in enumerate(classes):
			class_df = df[df['Class'] == class_name]
			# 按照索引从小到大的顺序排序
			class_df = class_df.sort_index()
			# 添加气泡
			sc = ax.scatter(class_df['Rich_factor'],class_df.index, s=class_df['HitsGenesCountsInSelectedSet']*10, c=self.value_to_color(class_df['corrected p-value(BH method)'],cmap,df['corrected p-value(BH method)'].min(), df['corrected p-value(BH method)'].max()), alpha=0.7, edgecolors='k')
			# 获取scatter plot 的边界框信息
			index = class_df['index'].to_list()
			xmin, xmax = xvaluemin-0.005,xvaluemax+0.005
			ymin, ymax = min(index)-0.5,max(index)+0.5
			# 添加矩形
			rect = plt.Rectangle((xmin, ymin), xmax - xmin, ymax - ymin, alpha=0.1, color=Class_dic[class_name], edgecolor=None)
			ax.add_patch(rect)

		ax.scatter(xvaluemax+0.003,1, s=1*10, c='#c8c2c6', alpha=0.7, edgecolors='k')
		ax.text(xvaluemax+0.003+0.0005,1, '1', fontsize=12, ha='left', va='center')
		ax.scatter(xvaluemax+0.003,1.8, s=5*10, c='#c8c2c6', alpha=0.7, edgecolors='k')
		ax.text(xvaluemax+0.003+0.0005,1.8, '5', fontsize=12, ha='left', va='center')
		ax.scatter(xvaluemax+0.003,2.6, s=10*10, c='#c8c2c6', alpha=0.7, edgecolors='k')
		ax.text(xvaluemax+0.003+0.0005,2.6, '10', fontsize=12, ha='left', va='center')

		# 设置纵轴标签
		plt.yticks(df.index, [index_to_go_name[i] for i in df.index])

		# 添加颜色条
		cbar = fig.colorbar(plt.cm.ScalarMappable(cmap=cmap), ax=ax)
		cbar.set_label('corrected p-value')

		plt.xlabel('Rich factor')
		plt.ylabel('GO Name')
		plt.title('GO Enrichment Bubble Plot')

		plt.tight_layout()

		plt.savefig(self.savefile, dpi = int(self.dpi), bbox_inches = 'tight')

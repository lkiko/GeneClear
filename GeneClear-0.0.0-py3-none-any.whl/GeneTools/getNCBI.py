# python
# -*- encoding: utf-8 -*-
'''
@File        :bio.py
@Time        :2021/04/27 19:54:08
@Author        :charles kiko
@Version        :1.0
@Contact        :charles_kiko@163.com
@Desc        :python bio.py gff pep cds ncbi/embl xxx
@annotation        :
'''

import sys
import ast
import os
import gc# 内存管理模块
from tqdm import trange
from Bio.Seq import Seq
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord

import numpy as np
import pandas as pd

class getNCBI():
    def __init__(self):
        self.gene_r8_Separator1 = ';' # 基因注释外部分隔符
        self.gene_r8_Separator2 = '=' # 基因注释名与注释值分隔符
        self.gene_row_key = 'ID'
        self.mrna_gene_key = 'Parent'
        self.mrna_row_key = 'ID'
        self.NCBIgff3 = 'x.gff3'
        self.NCBIpep = 'x.gff3'
        self.NCBIcds = 'x.gff3'
        self.Species = 'x.gff3'

    def read_r8(self,s):
        dic = {}
        lt = s.split(self.gene_r8_Separator1)
        for i in lt:
            if self.gene_r8_Separator2 in i:
                lt0 = i.split(self.gene_r8_Separator2)
                dic[lt0[0]] = lt0[1]
        return dic

    def get_chr(self,chr0):
        return self.Species + chr0[3:]

    def ncbi_gff(self):
        if os.path.exists(self.Species+'_gene.gff'):
            os.remove(self.Species+'_gene.gff')
        if os.path.exists(self.Species+'_mrna.gff'):
            os.remove(self.Species+'_mrna.gff')
        if os.path.exists(self.Species+'.cds'):
            os.remove(self.Species+'.cds')
        if os.path.exists(self.Species+'.pep'):
            os.remove(self.Species+'.pep')


        gff = pd.read_csv(self.NCBIgff3,header = None, sep='\t')
        gff[0] = gff[0].map(self.get_chr)
        dic = gff.groupby(2).groups# 按照第几列分组
        gene = gff.loc[dic['gene']].sort_values(by=[0,3],ascending= [True,True])
        gene.reset_index(drop=True,inplace=True)
        # print(gene)

        # 基因分染色体
        lens = open(self.Species+".lens",'w')
        dic0 = gene.groupby(0).groups
        gene_dic = {}
        for key in dic0.keys():
            print(" ******** ",key," ******** ")
            local = gene.loc[dic0[key]].sort_values(by=[0,3],ascending= [True,True])
            local.reset_index(drop=True,inplace=True)
            print(local)
            for index,row in local.iterrows():
                name = row[0] + 'g' + str(index+1).zfill(4)
                local.loc[index,1] = name
                old_name = self.read_r8(row[8])[self.gene_row_key]
                local.loc[index,8] = old_name
                local.loc[index,7] = index+1
                gene_dic[old_name] = name
            row_1 = local.iloc[-1].tolist()
            lens_s = [key,str(row_1[4]),str(int(row_1[7]))]
            lens.write('\t'.join(lens_s)+'\n')
            # local = local.drop([2,5], 1,inplace=True)
            local = local[[0,1,3,4,6,7,8]]
            local.to_csv(self.Species+'_gene.gff', index=False, header=False,sep='\t',mode='a+')
            print(local)
        del dic0,local

        pepdoc = self.readncbipep()
        cdsdoc = self.readncbicds()

        pep = open(self.Species+'.pep','w')
        cds = open(self.Species+'.cds','w')
        pepdoc1,cdsdoc1 = {},{}
        mrna = gff.loc[dic['mRNA']].sort_values(by=[0,3],ascending= [True,True])
        mrna.reset_index(drop=True,inplace=True)
        dic0 = mrna.groupby(0).groups
        # mrna_dic = {}
        for key in dic0.keys():
            print(" ******** ",key," ******** ")
            local = mrna.loc[dic0[key]].sort_values(by=[0,3],ascending= [True,True])
            local.reset_index(drop=True,inplace=True)
            print(local)
            for index,row in local.iterrows():
                gene_name = self.read_r8(row[8])[self.mrna_gene_key]
                tran_name = self.read_r8(row[8])[self.mrna_row_key]
                name = gene_dic[gene_name]
                local.loc[index,1] = name
                local.loc[index,8] = gene_name
                # gene_dic[old_name] = name
                if name not in cdsdoc1.keys() and tran_name in cdsdoc.keys() and tran_name in pepdoc.keys():
                    cdsdoc1[name] = SeqRecord(Seq(str(cdsdoc[tran_name].seq)),id=name,name=name,description=gene_name)
                    pepdoc1[name] = SeqRecord(Seq(str(pepdoc[tran_name].seq)),id=name,name=name,description=gene_name)
                elif name in cdsdoc1.keys() and tran_name in cdsdoc.keys() and tran_name in pepdoc.keys():
                    if len(str(cdsdoc[tran_name].seq)) > len(str(cdsdoc1[name].seq)):
                        cdsdoc1[name] = SeqRecord(Seq(str(cdsdoc[tran_name].seq)),id=name,name=name,description=gene_name)
                        pepdoc1[name] = SeqRecord(Seq(str(pepdoc[tran_name].seq)),id=name,name=name,description=gene_name)
                    else:
                        continue
            local = local[[0,1,3,4,6,7,8]]
            local.to_csv(self.Species+'_mrna.gff', index=False, header=False,sep='\t',mode='a+')
            print(local)
        for key in cdsdoc1.keys():
            SeqIO.write(cdsdoc1[key], cds, "fasta")
            SeqIO.write(pepdoc1[key], pep, "fasta")

        pep.close()
        cds.close()


    def genenum(self,gfflist):
        num = 0# 计数
        for gff in gfflist:
            if gff[2] == 'gene':
                num += 1
            else:
                pass
        k = len(str(num))
        return k

    def readncbipep(self):
        print('reading ncbi-pep')
        pep = SeqIO.to_dict(SeqIO.parse(self.NCBIpep, "fasta"))# 提取之后直接返回字典
        print('PEP of number is ',len(pep))
        return pep

    def readncbicds(self):
        print('reading ncbi-cds')
        cds = SeqIO.to_dict(SeqIO.parse(self.NCBIcds, "fasta"))# 提取之后直接返回字典
        print('CDS of number is ',len(cds))
        return cds

    def sequence(self,chrlist):
        newchr = {}
        doc = {}
        for i in chrlist:
            doc[str(i)] = int(i[1])
        dic1SortList = sorted(doc.items(),key = lambda x:x[1],reverse = True)
        for j in range(len(dic1SortList)):
            lt0 = ast.literal_eval(dic1SortList[j][0])
            lt0.append(j + 1)
            newchr[lt0[0]] = lt0
        return newchr

    def filewrite(self,file,name,seq):
        f = open(file,'a+',encoding = 'utf-8')
        f.write('>' + name + '\n')
        f.write(seq)
        f.close()

    def writegff(self,file,lt):
        f = open(file,'a+',encoding = 'utf-8')
        f.write(str(self.Species) + str(lt[0]) + '\t' + str(lt[1]) + '\t' \
            + str(lt[2]) + '\t' + str(lt[3]) + '\t' \
            + str(lt[4]) + '\t' +str(lt[5]) + '\t' \
            +str(lt[6]) + '\n')
        f.close()

    def writelens(self,file,lt):
        f = open(file,'a+',encoding = 'utf-8')
        f.write(str(self.Species) + str(lt[0]) + '\t' + str(lt[1]) + '\t' \
            + str(lt[2]) + '\n')
        f.close()

    def runncbi(self):
        self.ncbi_gff()
        exit()

        pepdoc = self.readncbipep()
        cdsdoc = self.readncbicds()
        genenum = self.genenum(gfflist)
        chrdoc1 = self.sequence(chrlist)
        genenums = 0
        print('gff文件筛选及cds、pep生成')
        for i in trange(len(gfflist)):
            gffrow = gfflist[i]
            if gffrow[2] == 'mRNA':
                gene = str(gffrow[8]['gene'])## 注意
                if gene in cdsdoc.keys() and str(cdsdoc[gene][0]) in pepdoc.keys():
                    genenums += 1
                    ol_chr = str(gffrow[0])
                    if len(str(chrdoc1[ol_chr][0])) <= 10 and str(chrdoc1[ol_chr][0]) != 'Unknown':
                        newchrname = chrdoc1[ol_chr][-2]
                    else:
                        newchrname = chrdoc1[ol_chr][-1]
                    # 在这儿修改名字，需求按照染色体长度排序
                    newname = self.Species + str(newchrname) + 'g' + str(genenums).zfill(genenum)
                    self.filewrite(self.Species + '.pep',newname,pepdoc[str(cdsdoc[gene][0])])
                    self.filewrite(self.Species + '.cds',newname,cdsdoc[gene][1])
                    lt0 = [gffrow[0],gffrow[3],gffrow[4],gffrow[6],str(gene),newchrname,newname]
                    self.gff.append(lt0)
                elif gene in cdsdoc.keys():
                    genenums += 1
                    ol_chr = str(gffrow[0])
                    if len(str(chrdoc1[ol_chr][0])) <= 10 and str(chrdoc1[ol_chr][0]) != 'Unknown':
                        newchrname = chrdoc1[ol_chr][-2]
                    else:
                        newchrname = chrdoc1[ol_chr][-1]
                    # 在这儿修改名字，需求按照染色体长度排序
                    newname = self.Species + str(newchrname) + 'g' + str(genenums).zfill(genenum)
                    # self.filewrite(self.Species + '.pep',newname,pepdoc[str(cdsdoc[gene][0])])
                    self.filewrite(self.Species + '.cds',newname,cdsdoc[gene][1])
                    lt0 = [gffrow[0],gffrow[3],gffrow[4],gffrow[6],str(gene),newchrname,newname]
                    self.gff.append(lt0)
                else:
                    pass
        gc.collect()# 内存释放
        genenum1 = 1
        chrlist0 = []
        chr0 = []
        print('gff、lens生成')
        for i in trange(len(self.gff)):
            gene = self.gff[i]
            if gene[-2] not in chrlist0:
                if chr0 != []:
                    self.writelens(str(self.Species) + '.lens', chr0)
                    chr0 = []
                chrlist0.append(gene[-2])
                genenum1 = 1
                lt = [gene[-2],gene[-1],gene[1],gene[2],gene[3],genenum1,gene[4]]
                self.writegff(str(self.Species) + '.gff', lt)
            else:
                genenum1 += 1
                chr0 = []
                chr0 = chr0 + [gene[-2],chrdoc1[gene[0]][1],genenum1]
                lt = [gene[-2],gene[-1],gene[1],gene[2],gene[3],genenum1,gene[4]]
                self.writegff(str(self.Species) + '.gff', lt)
        if chr0 != []:
            self.writelens(str(self.Species) + '.lens', chr0)

    def run(self):
        self.runncbi()


# data = getNCBI()
# data.run()